Day 1
====

This is the first day that I am writing on this blog tool I've got here.

