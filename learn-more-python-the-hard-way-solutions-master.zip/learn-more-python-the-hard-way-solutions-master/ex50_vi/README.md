Puny Vi Notes
=====

* First get the modules in
* Then get a simple curses screen going
* Then have the gutter commands for ed change the file display
* Then do a cleaner display method that doesn't totally repaint
* Maybe find a way to test it.
